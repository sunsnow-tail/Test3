﻿namespace CountryWeather.Models
{
    public class LocationWeatherData
    {
        public string lon { get; set; }
        public string lat { get; set; }
    }
}
