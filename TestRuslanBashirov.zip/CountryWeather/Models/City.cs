﻿namespace CountryWeather.Models
{
    public class City
    {
        public string Name { get; set; }
    }
}