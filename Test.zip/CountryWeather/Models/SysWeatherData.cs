﻿namespace CountryWeather.Models
{
    /// <summary>
    /// keeps system values from service
    /// </summary>
    public class SysWeatherData
    {
        public string Country { get; set; }
    }
}
