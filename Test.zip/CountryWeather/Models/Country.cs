﻿namespace CountryWeather.Models
{
    public class Country
    {
        public string Name { get; set; }
    }
}