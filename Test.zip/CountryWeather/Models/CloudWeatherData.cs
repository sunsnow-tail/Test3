﻿namespace CountryWeather.Models
{
    public class CloudWeatherData
    {
        public string All { get; set; }
    }
}
