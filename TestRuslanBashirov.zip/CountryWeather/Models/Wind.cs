﻿namespace CountryWeather.Models
{
    public class Wind
    {
        public string Speed { get; set; }
        public string Deg { get; set; }
    }
}
